from yolox.exp import Exp as MyExp

class Exp(MyExp):
    def __init__(self):
        super().__init__()

        #self.num_classes = 7
        #self.cls_names = ("cast", "cryst", "epith", "epithn", "eryth", "leuko", "mycete")
        self.num_classes = 2
        self.cls_names = ("epith", "rbc/wbc")
        
        self.depth = 1.0
        self.width = 1.0
        self.vit = True
        self.data_dir = "datasets/"  # base path
        self.train_ann = "instances_train.json"
        self.val_ann = "instances_val.json"
        self.test_ann = "instances_test.json"

        self.input_size = (640, 640)
        self.test_size = (640, 640)
        self.exp_name = "vit_yolo_uti-EV"

        # Set correct paths to image folders:
        self.train_name = "train/images"
        self.val_name = "val/images"
        self.test_name = "test/images"

        self.max_epoch = 100
        self.data_num_workers = 4
        self.eval_interval = 1