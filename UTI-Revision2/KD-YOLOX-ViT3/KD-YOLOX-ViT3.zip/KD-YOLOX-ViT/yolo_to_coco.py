import os
import json
from PIL import Image
from tqdm import tqdm

def yolo_to_coco(yolo_img_dir, yolo_ann_dir, output_json, class_list, starting_img_id=0, starting_ann_id=0):
    categories = [{'id': i, 'name': cls, 'supercategory': 'none'} for i, cls in enumerate(class_list)]
    images = []
    annotations = []

    ann_id = starting_ann_id
    img_id = starting_img_id

    for img_file in tqdm(os.listdir(yolo_img_dir), desc=f"Processing {os.path.basename(output_json)}"):
        if not img_file.lower().endswith(('.jpg', '.jpeg', '.png')):
            continue

        img_path = os.path.join(yolo_img_dir, img_file)
        ann_path = os.path.join(yolo_ann_dir, os.path.splitext(img_file)[0] + '.txt')

        try:
            img = Image.open(img_path)
            width, height = img.size
        except:
            print(f"⚠️ Skipping unreadable image: {img_path}")
            continue

        images.append({
            'id': img_id,
            'file_name': img_file,
            'width': width,
            'height': height
        })

        if os.path.exists(ann_path):
            with open(ann_path, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) != 5:
                        continue

                    cls_id, cx, cy, w, h = map(float, parts)
                    cls_id = int(cls_id)

                    x = (cx - w / 2) * width
                    y = (cy - h / 2) * height
                    bw = w * width
                    bh = h * height

                    annotations.append({
                        'id': ann_id,
                        'image_id': img_id,
                        'category_id': cls_id,
                        'bbox': [x, y, bw, bh],
                        'area': bw * bh,
                        'iscrowd': 0,
                        'segmentation': []
                    })
                    ann_id += 1

        img_id += 1

    return {
        'images': images,
        'annotations': annotations,
        'categories': categories
    }

if __name__ == '__main__':
    base_dir = 'Data'
    splits = ['train', 'val', 'test']

    class_list = [
        'cast',
        'cryst',
        'epith',
        'epithn',
        'eryth',
        'leuko',
        'mycete'
    ]

    os.makedirs(os.path.join(base_dir, 'annotations'), exist_ok=True)

    img_id_offset = 0
    ann_id_offset = 0

    for split in splits:
        img_dir = os.path.join(base_dir, split, 'images')
        ann_dir = os.path.join(base_dir, split, 'labels')
        out_json = os.path.join(base_dir, 'annotations', f'instances_{split}.json')

        coco_data = yolo_to_coco(img_dir, ann_dir, out_json, class_list,
                                 starting_img_id=img_id_offset, starting_ann_id=ann_id_offset)

        with open(out_json, 'w') as f:
            json.dump(coco_data, f, indent=4)

        img_id_offset += len(coco_data['images'])
        ann_id_offset += len(coco_data['annotations'])

    print("✅ All YOLO datasets converted to COCO format!")
